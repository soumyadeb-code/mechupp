<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mechupp — Bike Repair, On Demand | Aethenox Moto</title>
    <meta name="description" content="Mechupp connects riders with trusted mechanics nearby. Pre-register now and earn early-rider rewards.">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Barlow:wght@400;600;700&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.jsx']); ?>
</head>
<body class="bg-background text-foreground antialiased font-body min-h-screen">
    <div id="app"></div>
</body>
</html>
<?php /**PATH E:\AI\Production\Bihar\mechupp-update\resources\views/app.blade.php ENDPATH**/ ?>